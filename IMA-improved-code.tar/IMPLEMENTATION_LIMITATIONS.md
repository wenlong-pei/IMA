# 无法在当前环境实现的功能及解决方案

## 环境限制说明
当前运行环境磁盘空间严重不足（仅 118MB 可用），无法安装新的 npm 依赖包。以下功能需要在本地开发环境中实现。

---

## 1. API Key 加密存储

### 问题描述
当前 API Key 以明文形式存储在 `electron-store` 中，存在安全风险。需要使用 `electron-safe-storage` 进行加密。

### 无法实现原因
需要安装新依赖包：
```bash
npm install electron-safe-storage
```
当前环境磁盘空间不足，无法执行 npm install。

### 具体解决方案

#### 步骤 1：安装依赖
```bash
npm install electron-safe-storage
```

#### 步骤 2：创建加密工具类
在 `src/utils/SecureStorage.ts` 创建：

```typescript
import safeStorage from 'electron-safe-storage'

export class SecureStorage {
  private static readonly KEY_PREFIX = 'pilaoban_'
  
  static async set(key: string, value: string): Promise<void> {
    try {
      const encryptedKey = this.KEY_PREFIX + key
      await safeStorage.setEncrypted(encryptedKey, value)
    } catch (error) {
      console.error('Failed to encrypt storage:', error)
      throw new Error('加密存储失败')
    }
  }
  
  static async get(key: string): Promise<string | null> {
    try {
      const encryptedKey = this.KEY_PREFIX + key
      return await safeStorage.getEncrypted(encryptedKey)
    } catch (error) {
      console.error('Failed to decrypt storage:', error)
      return null
    }
  }
  
  static async delete(key: string): Promise<void> {
    try {
      const encryptedKey = this.KEY_PREFIX + key
      await safeStorage.deleteEncrypted(encryptedKey)
    } catch (error) {
      console.error('Failed to delete encrypted storage:', error)
    }
  }
}
```

#### 步骤 3：修改 Electron 主进程
在 `electron/main.ts` 中添加 IPC 处理：

```typescript
import { SecureStorage } from '../src/utils/SecureStorage'

ipcMain.handle('secure-storage:set', async (_, key: string, value: string) => {
  return SecureStorage.set(key, value)
})

ipcMain.handle('secure-storage:get', async (_, key: string) => {
  return SecureStorage.get(key)
})

ipcMain.handle('secure-storage:delete', async (_, key: string) => {
  return SecureStorage.delete(key)
})
```

#### 步骤 4：修改 preload.ts
```typescript
contextBridge.exposeInMainWorld('secureStorage', {
  set: (key: string, value: string) => ipcRenderer.invoke('secure-storage:set', key, value),
  get: (key: string) => ipcRenderer.invoke('secure-storage:get', key),
  delete: (key: string) => ipcRenderer.invoke('secure-storage:delete', key),
})
```

#### 步骤 5：在 SettingsPage 中使用
替换原有的明文存储调用为加密存储。

---

## 2. DOM 选择器外置配置

### 问题描述
智学网页面选择器硬编码在 `electron/main.ts` 中，网站更新时需要重新编译发布。应外置为 JSON 文件支持热更新。

### 无法实现原因
需要创建外部配置文件并修改加载逻辑，涉及文件系统操作和构建配置调整。

### 具体解决方案

#### 步骤 1：创建选择器配置文件
在项目根目录创建 `configs/selectors.json`：

```json
{
  "zhixue": {
    "version": "2025.01",
    "lastUpdated": "2025-01-15",
    "selectors": {
      "ANSWER_IMAGE": "div[name=\"topicImg\"] img",
      "SCORE_INPUT": "input[type=\"number\"]",
      "SCORE_INPUT_PLACEHOLDER": "input[placeholder*=\"分\"]",
      "SUBMIT_BUTTON_TEXT": "提交分数",
      "ANSWER_IMAGE_NEW": ".enhance-definition-bright",
      "SCORE_INPUT_NEW": "#txt_marking_17",
      "SCORE_INPUT_ALL_NEW": "#txt_marking_all",
      "SUBMIT_BUTTON_NEW": "#bnt_save"
    },
    "fallbackSelectors": {
      "ANSWER_IMAGE": [".answer-img", ".student-answer img", "[class*=\"answer\"] img"],
      "SCORE_INPUT": ["input[type=\"number\"]", ".score-input", "[placeholder*=\"分数\"]"]
    }
  },
  "general": {
    "answerArea": [".answer-content", ".student-answer", "[class*=\"answer\"]"],
    "scoreInput": ["input[type=\"number\"]", ".score-input", "[placeholder*=\"分数\"]"],
    "submitButton": ["button[type=\"submit\"]", ".submit-btn", ".btn-submit"]
  }
}
```

#### 步骤 2：修改 Electron 主进程加载逻辑
```typescript
import * as path from 'path'
import * as fs from 'fs'

function loadSelectors() {
  const configPath = isDev 
    ? path.join(__dirname, '../configs/selectors.json')
    : path.join(process.resourcesPath, 'configs/selectors.json')
  
  try {
    const data = fs.readFileSync(configPath, 'utf-8')
    return JSON.parse(data)
  } catch (error) {
    console.error('Failed to load selectors config, using defaults:', error)
    return getDefaultSelectors()
  }
}

// 添加热重载支持
const selectorsConfig = loadSelectors()

// 监听配置文件变化（开发模式）
if (isDev) {
  const configPath = path.join(__dirname, '../configs/selectors.json')
  fs.watch(configPath, (eventType) => {
    if (eventType === 'change') {
      console.log('Selectors config changed, reloading...')
      Object.assign(selectorsConfig, loadSelectors())
      mainWindow?.webContents.send('selectors:updated', selectorsConfig)
    }
  })
}
```

#### 步骤 3：修改 electron-builder 配置
在 `package.json` 的 `build` 部分添加：

```json
"extraResources": [
  "configs/**/*"
]
```

#### 步骤 4：添加 IPC 通信
```typescript
ipcMain.handle('selectors:get', () => selectorsConfig)
ipcMain.handle('selectors:reload', () => {
  Object.assign(selectorsConfig, loadSelectors())
  return selectorsConfig
})
```

---

## 3. 单元测试（Vitest）

### 问题描述
项目缺少自动化测试，核心逻辑无测试覆盖。

### 无法实现原因
需要安装 Vitest 及相关依赖，当前环境磁盘空间不足。

### 具体解决方案

#### 步骤 1：安装依赖
```bash
npm install -D vitest @testing-library/react @testing-library/jest-dom jsdom
```

#### 步骤 2：配置 Vitest
创建 `vitest.config.ts`：

```typescript
import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './src/test/setup.ts',
    include: ['src/**/*.{test,spec}.{ts,tsx}'],
    coverage: {
      reporter: ['text', 'json', 'html'],
      exclude: ['node_modules/', 'src/test/'],
    },
  },
})
```

#### 步骤 3：创建测试设置文件
`src/test/setup.ts`：

```typescript
import '@testing-library/jest-dom'
```

#### 步骤 4：编写测试用例示例
`src/utils/AppError.test.ts`：

```typescript
import { describe, it, expect } from 'vitest'
import { AppError, ErrorCodes, ErrorUtils } from './AppError'

describe('AppError', () => {
  it('should create error with correct properties', () => {
    const error = new AppError('Test message', ErrorCodes.API_KEY_MISSING, 'high')
    
    expect(error.name).toBe('AppError')
    expect(error.code).toBe(ErrorCodes.API_KEY_MISSING)
    expect(error.severity).toBe('high')
    expect(error.message).toBe('Test message')
  })
  
  it('should convert unknown error to AppError', () => {
    const unknownError = new Error('Unknown error')
    const appError = AppError.fromError(unknownError, 'TEST_CODE')
    
    expect(appError).toBeInstanceOf(AppError)
    expect(appError.code).toBe('TEST_CODE')
  })
})

describe('ErrorUtils', () => {
  it('should return user friendly message', () => {
    const message = ErrorUtils.getUserFriendlyMessage(ErrorCodes.API_KEY_MISSING)
    expect(message).toContain('API Key')
  })
  
  it('should identify recoverable errors', () => {
    const lowError = new AppError('Low', 'LOW', 'low')
    const criticalError = new AppError('Critical', 'CRITICAL', 'critical')
    
    expect(ErrorUtils.isRecoverable(lowError)).toBe(true)
    expect(ErrorUtils.isRecoverable(criticalError)).toBe(false)
  })
})
```

#### 步骤 5：添加 npm 脚本
在 `package.json` 中添加：

```json
"scripts": {
  "test": "vitest",
  "test:run": "vitest run",
  "test:coverage": "vitest run --coverage"
}
```

---

## 4. 新手引导（Intro.js）

### 问题描述
新用户首次使用时缺乏引导，不知道如何配置和使用。

### 无法实现原因
需要安装 `intro.js` 或类似库。

### 具体解决方案

#### 步骤 1：安装依赖
```bash
npm install intro.js-react
```

#### 步骤 2：创建引导组件
`src/components/OnboardingTour.tsx`：

```typescript
import { useIntro } from 'intro.js-react'
import 'intro.js/introjs.css'

export function OnboardingTour() {
  const { intro, setIsOpen } = useIntro({
    steps: [
      {
        element: '#api-key-input',
        intro: '首先，请输入您的 API Key。这是使用 AI 评分功能的必要条件。',
        position: 'bottom',
      },
      {
        element: '#provider-select',
        intro: '选择您偏好的 AI 服务提供商，我们支持多家主流服务。',
        position: 'bottom',
      },
      {
        element: '#start-grading-btn',
        intro: '配置完成后，点击这里开始智能阅卷！',
        position: 'top',
      },
    ],
    showProgress: true,
    showBullets: false,
    exitOnOverlayClick: false,
  })

  // 首次启动时自动显示
  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding')
    if (!hasSeenOnboarding) {
      setIsOpen(true)
      localStorage.setItem('hasSeenOnboarding', 'true')
    }
  }, [])

  return null
}
```

---

## 5. CI/CD 自动化（GitHub Actions）

### 问题描述
手动构建发布效率低，容易出错。

### 无法实现原因
需要创建 GitHub Actions 工作流文件，这需要在实际的 Git 仓库中配置。

### 具体解决方案

#### 步骤 1：创建工作流文件
`.github/workflows/release.yml`：

```yaml
name: Release

on:
  push:
    tags:
      - 'v*'

jobs:
  release:
    runs-on: windows-latest
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build
        run: npm run build
        
      - name: Build Windows executable
        run: npm run dist:win
        
      - name: Create Release
        uses: softprops/action-gh-release@v1
        with:
          files: |
            release/*.exe
            release/*.zip
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

---

## 6. 自动更新（electron-updater）

### 问题描述
用户需要手动下载新版本，体验不佳。

### 无法实现原因
需要安装 `electron-updater` 并修改主进程代码。

### 具体解决方案

#### 步骤 1：安装依赖
```bash
npm install electron-updater
```

#### 步骤 2：修改主进程
```typescript
import { autoUpdater } from 'electron-updater'

function setupAutoUpdater() {
  autoUpdater.autoDownload = false
  
  autoUpdater.on('update-available', (info) => {
    dialog.showMessageBox(mainWindow!, {
      type: 'info',
      title: '发现新版本',
      message: `发现新版本 v${info.version}，是否立即下载？`,
      buttons: ['下载', '稍后'],
    }).then((result) => {
      if (result.response === 0) {
        autoUpdater.downloadUpdate()
      }
    })
  })
  
  autoUpdater.on('update-downloaded', () => {
    dialog.showMessageBox(mainWindow!, {
      type: 'info',
      title: '下载完成',
      message: '新版本已下载完成，重启应用以安装更新',
      buttons: ['重启', '稍后'],
    }).then((result) => {
      if (result.response === 0) {
        autoUpdater.quitAndInstall()
      }
    })
  })
  
  // 检查更新
  setTimeout(() => autoUpdater.checkForUpdates(), 5000)
}
```

---

## 实施建议优先级

| 功能 | 优先级 | 预计工时 | 难度 |
|------|--------|----------|------|
| API Key 加密存储 | 🔴 高 | 2 小时 | 简单 |
| DOM 选择器外置 | 🔴 高 | 3 小时 | 中等 |
| 单元测试 | 🟡 中 | 8 小时 | 中等 |
| 新手引导 | 🟡 中 | 4 小时 | 简单 |
| CI/CD | 🟢 低 | 2 小时 | 简单 |
| 自动更新 | 🟢 低 | 4 小时 | 中等 |

建议在本地开发环境中按优先级顺序逐步实施上述改进。
