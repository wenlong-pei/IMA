/**
 * 重试工具类
 * 提供智能重试机制，支持指数退避、自定义策略等
 */

import { AppError, ErrorUtils } from './AppError'

export interface RetryOptions {
  /** 最大重试次数 */
  maxRetries?: number
  /** 初始延迟（毫秒） */
  initialDelay?: number
  /** 最大延迟（毫秒） */
  maxDelay?: number
  /** 退避乘数 */
  backoffMultiplier?: number
  /** 是否使用指数退避 */
  exponentialBackoff?: boolean
  /** 可重试的错误代码列表 */
  retryableCodes?: string[]
  /** 每次重试前的回调 */
  onRetry?: (attempt: number, error: Error, delayMs: number) => void
  /** 成功回调 */
  onSuccess?: (result: any, attempt: number) => void
}

const DEFAULT_OPTIONS: Required<RetryOptions> = {
  maxRetries: 3,
  initialDelay: 1000,
  maxDelay: 30000,
  backoffMultiplier: 2,
  exponentialBackoff: true,
  retryableCodes: [
    'NETWORK_ERROR',
    'TIMEOUT_ERROR',
    'API_REQUEST_FAILED',
    'API_RATE_LIMITED',
  ],
  onRetry: () => {},
  onSuccess: () => {},
}

/**
 * 延迟函数
 */
export function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

/**
 * 计算下次重试延迟
 */
export function calculateDelay(
  attempt: number,
  options: Required<RetryOptions>
): number {
  if (!options.exponentialBackoff) {
    return options.initialDelay
  }

  const exponentialDelay = options.initialDelay * Math.pow(options.backoffMultiplier, attempt - 1)
  // 添加随机抖动（±25%），避免多个请求同时重试
  const jitter = exponentialDelay * 0.25 * (Math.random() * 2 - 1)
  const delayWithJitter = exponentialDelay + jitter

  return Math.min(delayWithJitter, options.maxDelay)
}

/**
 * 判断错误是否可重试
 */
export function isRetryableError(error: unknown, retryableCodes?: string[]): boolean {
  const appError = AppError.fromError(error)
  
  // 如果有自定义重试代码列表，优先使用
  if (retryableCodes && retryableCodes.length > 0) {
    return retryableCodes.includes(appError.code)
  }

  // 否则使用 ErrorUtils 的策略
  const strategy = ErrorUtils.getRetryStrategy(appError)
  return strategy.shouldRetry
}

/**
 * 带重试的异步操作执行器
 * 
 * @example
 * ```typescript
 * const result = await withRetry(
 *   () => apiService.call(),
 *   {
 *     maxRetries: 5,
 *     initialDelay: 1000,
 *     onRetry: (attempt, error, delay) => {
 *       console.log(`Retry ${attempt}: ${error.message}. Waiting ${delay}ms...`)
 *     }
 *   }
 * )
 * ```
 */
export async function withRetry<T>(
  operation: () => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const opts = { ...DEFAULT_OPTIONS, ...options }
  let lastError: Error | null = null

  for (let attempt = 1; attempt <= opts.maxRetries; attempt++) {
    try {
      const result = await operation()
      
      // 成功回调（如果不是第一次尝试）
      if (attempt > 1 && opts.onSuccess) {
        opts.onSuccess(result, attempt)
      }
      
      return result
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error))
      
      // 检查是否应该重试
      if (!isRetryableError(error, opts.retryableCodes)) {
        throw error
      }

      // 如果是最后一次尝试，直接抛出错误
      if (attempt === opts.maxRetries) {
        throw lastError
      }

      // 计算延迟时间
      const delayMs = calculateDelay(attempt, opts)

      // 调用重试回调
      opts.onRetry(attempt, lastError, delayMs)

      // 等待后重试
      await delay(delayMs)
    }
  }

  // 理论上不会到达这里，但为了类型安全
  throw lastError || new Error('Unknown error')
}

/**
 * 重试执行器类，提供更灵活的控制
 */
export class RetryExecutor<T> {
  private operation: () => Promise<T>
  private options: Required<RetryOptions>
  private currentAttempt = 0
  private isCancelled = false

  constructor(operation: () => Promise<T>, options: RetryOptions = {}) {
    this.operation = operation
    this.options = { ...DEFAULT_OPTIONS, ...options }
  }

  /**
   * 取消重试
   */
  cancel(): void {
    this.isCancelled = true
  }

  /**
   * 执行重试逻辑
   */
  async execute(): Promise<T> {
    let lastError: Error | null = null

    while (this.currentAttempt < this.options.maxRetries && !this.isCancelled) {
      this.currentAttempt++

      try {
        const result = await this.operation()
        
        if (this.currentAttempt > 1 && this.options.onSuccess) {
          this.options.onSuccess(result, this.currentAttempt)
        }
        
        return result
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error))
        
        if (!isRetryableError(error, this.options.retryableCodes)) {
          throw error
        }

        if (this.isCancelled) {
          throw new AppError('Operation cancelled by user', 'OPERATION_CANCELLED', 'low')
        }

        if (this.currentAttempt >= this.options.maxRetries) {
          throw lastError
        }

        const delayMs = calculateDelay(this.currentAttempt, this.options)
        this.options.onRetry(this.currentAttempt, lastError, delayMs)

        // 使用 Promise.race 实现可取消的延迟
        await Promise.race([
          delay(delayMs),
          new Promise((_, reject) => {
            const checkCancel = setInterval(() => {
              if (this.isCancelled) {
                clearInterval(checkCancel)
                reject(new AppError('Operation cancelled', 'OPERATION_CANCELLED', 'low'))
              }
            }, 100)
          })
        ])
      }
    }

    throw lastError || new Error('Unknown error')
  }

  /**
   * 获取当前尝试次数
   */
  getAttemptCount(): number {
    return this.currentAttempt
  }
}

/**
 * 创建可取消的重试任务
 */
export function createRetryTask<T>(
  operation: () => Promise<T>,
  options: RetryOptions = {}
): { execute: () => Promise<T>; cancel: () => void } {
  const executor = new RetryExecutor(operation, options)
  
  return {
    execute: () => executor.execute(),
    cancel: () => executor.cancel(),
  }
}

/**
 * 轮询工具函数
 * 定期执行操作直到满足条件或超时
 */
export async function poll<T>(
  operation: () => Promise<T>,
  condition: (result: T) => boolean,
  options: {
    interval?: number
    timeout?: number
    maxAttempts?: number
  } = {}
): Promise<T> {
  const {
    interval = 1000,
    timeout = 30000,
    maxAttempts = 30,
  } = options

  const startTime = Date.now()
  let attempts = 0

  while (attempts < maxAttempts && Date.now() - startTime < timeout) {
    attempts++
    const result = await operation()

    if (condition(result)) {
      return result
    }

    await delay(interval)
  }

  throw new AppError(
    'Polling timeout or max attempts reached',
    'POLLING_TIMEOUT',
    'medium',
    { attempts, timeout, maxAttempts }
  )
}
