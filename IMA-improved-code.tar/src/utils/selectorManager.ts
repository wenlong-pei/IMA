/**
 * 选择器管理器
 * 从 JSON 配置加载和管理 DOM 选择器，支持热更新
 */

import selectorsConfig from '../config/selectors.json'

export interface SelectorConfig {
  answerImage: string
  scoreInput: string
  scoreInputPlaceholder?: string
  scoreInputAll?: string
  submitButton: string
  nextButton: string
}

export interface PlatformConfig {
  name: string
  domains: string[]
  uiVersions: {
    [key: string]: {
      name: string
      selectors: SelectorConfig
    }
  }
  detection: {
    [key: string]: string[]
  }
}

export interface SelectorsData {
  version: string
  lastUpdated: string
  platforms: {
    [key: string]: PlatformConfig
  }
  fallbacks: {
    [key: string]: string
  }
}

class SelectorManager {
  private config: SelectorsData
  private customSelectors: Map<string, Partial<SelectorConfig>> = new Map()

  constructor() {
    this.config = selectorsConfig as SelectorsData
  }

  /**
   * 获取平台配置
   */
  getPlatform(platformKey: string): PlatformConfig | null {
    return this.config.platforms[platformKey] || null
  }

  /**
   * 根据域名自动检测平台
   */
  detectPlatform(url: string): string | null {
    try {
      const urlObj = new URL(url)
      const domain = urlObj.hostname

      for (const [key, platform] of Object.entries(this.config.platforms)) {
        if (platform.domains.some(d => domain.includes(d))) {
          return key
        }
      }
    } catch {
      return null
    }

    return null
  }

  /**
   * 检测 UI 版本
   */
  async detectUIVersion(page: any, platformKey: string): Promise<string> {
    const platform = this.getPlatform(platformKey)
    if (!platform) return 'fallback'

    for (const [version, detectors] of Object.entries(platform.detection)) {
      for (const selector of detectors) {
        try {
          const element = await page.$(selector)
          if (element) {
            return version
          }
        } catch {
          continue
        }
      }
    }

    return 'fallback'
  }

  /**
   * 获取选择器
   */
  getSelectors(platformKey: string, uiVersion: string): SelectorConfig {
    const platform = this.getPlatform(platformKey)
    
    if (platform && platform.uiVersions[uiVersion]) {
      const versionSelectors = platform.uiVersions[uiVersion].selectors
      
      // 合并自定义选择器（优先级更高）
      const custom = this.customSelectors.get(`${platformKey}-${uiVersion}`)
      if (custom) {
        return { ...versionSelectors, ...custom }
      }
      
      return versionSelectors
    }

    // 返回通用回退选择器
    return {
      answerImage: this.config.fallbacks.answerArea,
      scoreInput: this.config.fallbacks.scoreInput,
      submitButton: this.config.fallbacks.submitButton,
      nextButton: this.config.fallbacks.nextButton,
    }
  }

  /**
   * 设置自定义选择器（运行时覆盖）
   */
  setCustomSelectors(platformKey: string, uiVersion: string, selectors: Partial<SelectorConfig>): void {
    this.customSelectors.set(`${platformKey}-${uiVersion}`, selectors)
  }

  /**
   * 清除自定义选择器
   */
  clearCustomSelectors(platformKey?: string, uiVersion?: string): void {
    if (platformKey && uiVersion) {
      this.customSelectors.delete(`${platformKey}-${uiVersion}`)
    } else if (platformKey) {
      for (const key of this.customSelectors.keys()) {
        if (key.startsWith(`${platformKey}-`)) {
          this.customSelectors.delete(key)
        }
      }
    } else {
      this.customSelectors.clear()
    }
  }

  /**
   * 动态加载远程选择器配置（热更新）
   */
  async loadRemoteConfig(url: string): Promise<boolean> {
    try {
      const response = await fetch(url)
      if (!response.ok) throw new Error(`HTTP ${response.status}`)
      
      const remoteConfig = await response.json() as SelectorsData
      
      // 验证配置格式
      if (!remoteConfig.platforms || !remoteConfig.fallbacks) {
        throw new Error('Invalid config format')
      }

      // 只在版本更新时替换
      if (remoteConfig.version !== this.config.version) {
        this.config = remoteConfig
        console.log(`[SelectorManager] Config updated to ${remoteConfig.version}`)
        return true
      }
      
      return false
    } catch (error) {
      console.error('[SelectorManager] Failed to load remote config:', error)
      return false
    }
  }

  /**
   * 获取配置版本信息
   */
  getVersionInfo(): { version: string; lastUpdated: string } {
    return {
      version: this.config.version,
      lastUpdated: this.config.lastUpdated,
    }
  }

  /**
   * 导出当前配置（用于调试）
   */
  exportConfig(): SelectorsData {
    return { ...this.config }
  }
}

// 单例实例
export const selectorManager = new SelectorManager()

// 默认导出
export default selectorManager
