/**
 * 统一应用错误类
 * 用于标准化错误处理和用户友好的错误消息
 */

export class AppError extends Error {
  code: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  details?: Record<string, any>
  timestamp: Date

  constructor(
    message: string,
    code: string = 'UNKNOWN_ERROR',
    severity: 'low' | 'medium' | 'high' | 'critical' = 'medium',
    details?: Record<string, any>
  ) {
    super(message)
    this.name = 'AppError'
    this.code = code
    this.severity = severity
    this.details = details
    this.timestamp = new Date()
    
    // 保持正确的堆栈跟踪
    Error.captureStackTrace(this, AppError)
  }

  toJSON() {
    return {
      name: this.name,
      message: this.message,
      code: this.code,
      severity: this.severity,
      details: this.details,
      timestamp: this.timestamp.toISOString(),
      stack: this.stack,
    }
  }

  static fromError(error: unknown, defaultCode = 'UNKNOWN_ERROR'): AppError {
    if (error instanceof AppError) {
      return error
    }
    
    if (error instanceof Error) {
      return new AppError(
        error.message,
        defaultCode,
        'medium',
        { originalStack: error.stack }
      )
    }
    
    return new AppError(
      String(error),
      defaultCode,
      'medium',
      { rawError: error }
    )
  }
}

/**
 * 预定义的错误代码和消息
 */
export const ErrorCodes = {
  // API 相关
  API_KEY_MISSING: 'API_KEY_MISSING',
  API_REQUEST_FAILED: 'API_REQUEST_FAILED',
  API_RATE_LIMITED: 'API_RATE_LIMITED',
  
  // 文件操作
  FILE_NOT_FOUND: 'FILE_NOT_FOUND',
  FILE_READ_ERROR: 'FILE_READ_ERROR',
  FILE_WRITE_ERROR: 'FILE_WRITE_ERROR',
  
  // 浏览器自动化
  BROWSER_LAUNCH_FAILED: 'BROWSER_LAUNCH_FAILED',
  PAGE_NOT_FOUND: 'PAGE_NOT_FOUND',
  ELEMENT_NOT_FOUND: 'ELEMENT_NOT_FOUND',
  AUTOMATION_TIMEOUT: 'AUTOMATION_TIMEOUT',
  
  // OCR 相关
  OCR_FAILED: 'OCR_FAILED',
  IMAGE_PROCESSING_ERROR: 'IMAGE_PROCESSING_ERROR',
  
  // 网络相关
  NETWORK_ERROR: 'NETWORK_ERROR',
  TIMEOUT_ERROR: 'TIMEOUT_ERROR',
  
  // 配置相关
  CONFIG_INVALID: 'CONFIG_INVALID',
  CONFIG_NOT_FOUND: 'CONFIG_NOT_FOUND',
  
  // 系统相关
  INSUFFICIENT_PERMISSIONS: 'INSUFFICIENT_PERMISSIONS',
  DISK_SPACE_LOW: 'DISK_SPACE_LOW',
  MEMORY_LOW: 'MEMORY_LOW',
} as const

/**
 * 错误工具函数
 */
export const ErrorUtils = {
  /**
   * 根据错误代码获取用户友好的消息
   */
  getUserFriendlyMessage(code: string, context?: Record<string, any>): string {
    const messages: Record<string, string> = {
      [ErrorCodes.API_KEY_MISSING]: 'API Key 未设置，请在设置页面配置',
      [ErrorCodes.API_REQUEST_FAILED]: 'API 请求失败，请检查网络连接或稍后重试',
      [ErrorCodes.API_RATE_LIMITED]: '请求过于频繁，请稍后再试',
      [ErrorCodes.FILE_NOT_FOUND]: '文件不存在，请确认路径正确',
      [ErrorCodes.FILE_READ_ERROR]: '读取文件失败，请检查文件权限',
      [ErrorCodes.FILE_WRITE_ERROR]: '写入文件失败，磁盘空间可能不足',
      [ErrorCodes.BROWSER_LAUNCH_FAILED]: '无法启动浏览器，请确保已安装 Chrome 或 Edge',
      [ErrorCodes.PAGE_NOT_FOUND]: '页面未找到，请确认网址正确',
      [ErrorCodes.ELEMENT_NOT_FOUND]: '未找到目标元素，页面可能已更新',
      [ErrorCodes.AUTOMATION_TIMEOUT]: '操作超时，请检查网络连接',
      [ErrorCodes.OCR_FAILED]: 'OCR 识别失败，请重试或更换图片',
      [ErrorCodes.IMAGE_PROCESSING_ERROR]: '图片处理失败，请确认图片格式正确',
      [ErrorCodes.NETWORK_ERROR]: '网络连接失败，请检查网络设置',
      [ErrorCodes.TIMEOUT_ERROR]: '请求超时，请检查网络连接',
      [ErrorCodes.CONFIG_INVALID]: '配置文件格式错误，请检查配置',
      [ErrorCodes.CONFIG_NOT_FOUND]: '未找到配置文件，将使用默认配置',
      [ErrorCodes.INSUFFICIENT_PERMISSIONS]: '权限不足，请以管理员身份运行',
      [ErrorCodes.DISK_SPACE_LOW]: '磁盘空间不足，请清理空间后重试',
      [ErrorCodes.MEMORY_LOW]: '内存不足，请关闭其他程序后重试',
    }

    let message = messages[code] || '发生未知错误'
    
    // 替换上下文变量
    if (context) {
      Object.entries(context).forEach(([key, value]) => {
        message = message.replace(`{${key}}`, String(value))
      })
    }
    
    return message
  },

  /**
   * 判断错误是否可恢复
   */
  isRecoverable(error: AppError): boolean {
    return error.severity !== 'critical'
  },

  /**
   * 建议的重试策略
   */
  getRetryStrategy(error: AppError): { shouldRetry: boolean; delayMs?: number; maxRetries?: number } {
    switch (error.code) {
      case ErrorCodes.API_RATE_LIMITED:
        return { shouldRetry: true, delayMs: 5000, maxRetries: 3 }
      case ErrorCodes.NETWORK_ERROR:
      case ErrorCodes.TIMEOUT_ERROR:
        return { shouldRetry: true, delayMs: 2000, maxRetries: 3 }
      case ErrorCodes.API_REQUEST_FAILED:
        return { shouldRetry: true, delayMs: 1000, maxRetries: 2 }
      default:
        return { shouldRetry: false }
    }
  },
}
