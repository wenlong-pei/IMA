# 配置验证器

**功能**: 验证用户设置的合法性和安全性，防止无效或危险配置

## API

### `validateSettings(settings)`

验证应用设置对象。

```typescript
import { validateSettings } from '@/utils/configValidator'

const result = validateSettings({
  soundVolume: 120,  // 超出范围
  temperature: 3.0,  // 超出范围
})

console.log(result)
// {
//   valid: false,
//   errors: ['音量必须在 0-100 之间', 'temperature 必须在 0-2 之间'],
//   warnings: []
// }
```

### `validateSingleProvider(provider)`

验证单个 AI 服务商配置。

```typescript
import { validateSingleProvider } from '@/utils/configValidator'

const result = validateSingleProvider({
  id: 'deepseek',
  name: 'DeepSeek',
  endpoint: 'http://api.deepseek.com/...',  // 非 HTTPS
  apiKey: 'short',  // 太短
  model: 'deepseek-chat',
  isActive: true,
})

console.log(result)
// {
//   valid: false,
//   errors: [
//     '服务商 1: API 端点必须使用 HTTPS 协议（安全要求）',
//     '服务商 1: API Key 格式不正确（至少 10 个字符）'
//   ],
//   warnings: []
// }
```

### `validateZhixueUrl(url)`

验证智学网 URL。

```typescript
import { validateZhixueUrl } from '@/utils/configValidator'

const result = validateZhixueUrl('https://www.baidu.com')

console.log(result)
// { valid: false, error: '本工具仅支持智学网平台 (zhixue.com 或 zhixueyun.com)' }
```

### `validateGradingStandard(standard)`

验证评分标准。

```typescript
import { validateGradingStandard } from '@/utils/configValidator'

const result = validateGradingStandard({
  name: '',  // 空名称
  totalScore: 150,  // 超过 100
  referenceAnswer: '',  // 无参考答案
})

console.log(result)
// {
//   valid: false,
//   errors: ['评分标准名称不能为空', '总分必须大于 0'],
//   warnings: [
//     '总分超过 100 分，请确认是否正确',
//     '参考答案为空，可能影响评分准确性'
//   ]
// }
```

### `assertValidSettings(settings)`

验证设置，失败时抛出 `AppError`。

```typescript
import { assertValidSettings } from '@/utils/configValidator'

try {
  assertValidSettings({ soundVolume: 150 })
} catch (error) {
  console.error(error.message)  // '配置验证失败：音量必须在 0-100 之间'
}
```

## 验证规则

### 音效设置
- `soundVolume`: 0-100 的数字

### AI 设置
- `temperature`: 0-2 的数字（推荐 0.3-0.7）
- `maxTokens`: 100-8192 的数字

### 空白检测
- `blankDetectionThreshold`: 0-100 的数字

### PaddleOCR
- `paddleOcrUrl`: 有效的 HTTP/HTTPS URL
- `paddleOcrTimeout`: 5-600 秒

### 批改设置
- `autoSaveInterval`: 10-3600 秒
- `batchSize`: 1-100
- `retryAttempts`: 0-10

### 界面设置
- `theme`: 'light' | 'dark' | 'system'
- `fontSize`: 'small' | 'medium' | 'large'

### 服务商配置
- `name`: 非空字符串
- `endpoint`: 有效的 HTTPS URL
- `apiKey`: 至少 10 个字符（如果提供）
- `model`: 非空字符串

## 集成示例

### 在 SettingsStore 中使用

```typescript
// src/store/settingsStore.ts
import { validateSettings } from '@/utils/configValidator'

updateSettings: (updates) => {
  // 验证配置
  const validation = validateSettings(updates)
  if (!validation.valid) {
    throw new Error(`配置验证失败：${validation.errors.join(', ')}`)
  }
  
  // 记录警告
  if (validation.warnings.length > 0) {
    console.warn('配置警告:', validation.warnings)
  }
  
  set((state) => ({ settings: { ...state.settings, ...updates } }))
}
```

### 在设置页面中使用

```typescript
// src/pages/SettingsPage.tsx
import { validateSingleProvider } from '@/utils/configValidator'
import toast from 'react-hot-toast'

const handleSaveProvider = (provider) => {
  const result = validateSingleProvider(provider)
  
  if (!result.valid) {
    toast.error(result.errors.join('\n'))
    return
  }
  
  if (result.warnings.length > 0) {
    toast.warning(result.warnings.join('\n'))
  }
  
  // 保存配置
  updateProvider(provider.id, provider)
}
```

## 错误处理

所有验证函数返回 `ValidationResult` 对象：

```typescript
interface ValidationResult {
  valid: boolean      // 是否通过验证
  errors: string[]    // 错误列表（阻止操作）
  warnings: string[]  // 警告列表（不阻止操作）
}
```

这样设计的好处：
- **区分错误和警告**: 错误必须修复，警告可以忽略
- **批量验证**: 一次返回所有问题，用户可一次性修复
- **友好提示**: 错误消息清晰明确，指导用户如何修复
