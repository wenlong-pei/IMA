/**
 * 日志工具类
 * 提供结构化的日志记录功能，支持不同级别和输出格式
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error'

export interface LogEntry {
  timestamp: string
  level: LogLevel
  module: string
  message: string
  data?: any
  error?: {
    name: string
    message: string
    stack?: string
  }
}

export class Logger {
  private static instance: Logger
  private logs: LogEntry[] = []
  private maxLogs = 1000
  private enabledLevels: Set<LogLevel> = new Set(['debug', 'info', 'warn', 'error'])
  private module: string

  private constructor(module: string = 'App') {
    this.module = module
  }

  static getInstance(module: string = 'App'): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger(module)
    }
    return Logger.instance
  }

  static create(module: string): Logger {
    return new Logger(module)
  }

  setEnabledLevels(levels: LogLevel[]): void {
    this.enabledLevels = new Set(levels)
  }

  private shouldLog(level: LogLevel): boolean {
    return this.enabledLevels.has(level)
  }

  private formatTimestamp(): string {
    return new Date().toISOString()
  }

  private createEntry(
    level: LogLevel,
    message: string,
    data?: any,
    error?: Error
  ): LogEntry {
    const entry: LogEntry = {
      timestamp: this.formatTimestamp(),
      level,
      module: this.module,
      message,
    }

    if (data !== undefined) {
      entry.data = data
    }

    if (error) {
      entry.error = {
        name: error.name,
        message: error.message,
        stack: error.stack,
      }
    }

    return entry
  }

  private addEntry(entry: LogEntry): void {
    this.logs.push(entry)
    
    // 限制日志数量
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs)
    }

    // 输出到控制台
    this.outputToConsole(entry)
  }

  private outputToConsole(entry: LogEntry): void {
    const prefix = `[${entry.timestamp}] [${entry.level.toUpperCase()}] [${entry.module}]`
    
    switch (entry.level) {
      case 'debug':
        console.debug(prefix, entry.message, entry.data ?? '')
        break
      case 'info':
        console.info(prefix, entry.message, entry.data ?? '')
        break
      case 'warn':
        console.warn(prefix, entry.message, entry.data ?? '')
        break
      case 'error':
        console.error(prefix, entry.message, entry.error ?? entry.data ?? '')
        break
    }
  }

  debug(message: string, data?: any): void {
    if (this.shouldLog('debug')) {
      this.addEntry(this.createEntry('debug', message, data))
    }
  }

  info(message: string, data?: any): void {
    if (this.shouldLog('info')) {
      this.addEntry(this.createEntry('info', message, data))
    }
  }

  warn(message: string, data?: any): void {
    if (this.shouldLog('warn')) {
      this.addEntry(this.createEntry('warn', message, data))
    }
  }

  error(message: string, error?: Error | any, data?: any): void {
    if (this.shouldLog('error')) {
      const err = error instanceof Error ? error : null
      this.addEntry(this.createEntry('error', message, data, err))
    }
  }

  /**
   * 获取所有日志
   */
  getLogs(): LogEntry[] {
    return [...this.logs]
  }

  /**
   * 获取指定级别的日志
   */
  getLogsByLevel(level: LogLevel): LogEntry[] {
    return this.logs.filter(log => log.level === level)
  }

  /**
   * 获取最近 N 条日志
   */
  getRecentLogs(count: number = 100): LogEntry[] {
    return this.logs.slice(-count)
  }

  /**
   * 导出日志为 JSON
   */
  exportLogs(): string {
    return JSON.stringify(this.logs, null, 2)
  }

  /**
   * 清除日志
   */
  clear(): void {
    this.logs = []
  }

  /**
   * 保存日志到文件（Electron 环境）
   */
  async saveToFile(filePath: string): Promise<void> {
    if (typeof window !== 'undefined' && (window as any).electronAPI) {
      try {
        await (window as any).electronAPI.saveFile(
          filePath,
          this.exportLogs()
        )
        this.info(`Logs saved to ${filePath}`)
      } catch (error) {
        console.error('Failed to save logs:', error)
      }
    } else {
      // 浏览器环境：下载为文件
      this.downloadAsFile()
    }
  }

  /**
   * 下载日志文件（浏览器环境）
   */
  private downloadAsFile(): void {
    const blob = new Blob([this.exportLogs()], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `logs-${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }
}

// 预定义的日志实例
export const appLogger = Logger.getInstance('App')
export const gradingLogger = Logger.create('Grading')
export const apiLogger = Logger.create('API')
export const uiLogger = Logger.create('UI')

// 便捷导出
export const logger = appLogger
