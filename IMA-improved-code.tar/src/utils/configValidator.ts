/**
 * 配置验证工具
 * 验证用户设置的合法性和安全性
 */

import { AppError } from './AppError'
import type { AppSettings, AiProvider } from '@/types'

export interface ValidationResult {
  valid: boolean
  errors: string[]
  warnings: string[]
}

/**
 * 验证 URL 格式
 */
function isValidUrl(url: string): boolean {
  try {
    const parsed = new URL(url)
    return parsed.protocol === 'http:' || parsed.protocol === 'https:'
  } catch {
    return false
  }
}

/**
 * 验证 API Key 格式
 */
function isValidApiKey(apiKey: string): boolean {
  // API Key 至少 10 个字符
  return apiKey.length >= 10
}

/**
 * 验证服务商配置
 */
function validateProvider(provider: AiProvider, index: number): string[] {
  const errors: string[] = []
  
  if (!provider.name || provider.name.trim().length === 0) {
    errors.push(`服务商 ${index + 1}: 名称不能为空`)
  }
  
  if (!provider.endpoint) {
    errors.push(`服务商 ${index + 1}: API 端点不能为空`)
  } else if (!isValidUrl(provider.endpoint)) {
    errors.push(`服务商 ${index + 1}: API 端点必须是有效的 HTTP/HTTPS URL`)
  } else if (!provider.endpoint.startsWith('https://')) {
    errors.push(`服务商 ${index + 1}: API 端点必须使用 HTTPS 协议（安全要求）`)
  }
  
  if (provider.apiKey && !isValidApiKey(provider.apiKey)) {
    errors.push(`服务商 ${index + 1}: API Key 格式不正确（至少 10 个字符）`)
  }
  
  if (!provider.model || provider.model.trim().length === 0) {
    errors.push(`服务商 ${index + 1}: 模型名称不能为空`)
  }
  
  return errors
}

/**
 * 验证应用设置
 */
export function validateSettings(settings: Partial<AppSettings>): ValidationResult {
  const errors: string[] = []
  const warnings: string[] = []
  
  // 验证音效设置
  if (settings.soundVolume !== undefined) {
    if (typeof settings.soundVolume !== 'number') {
      errors.push('音量必须是数字')
    } else if (settings.soundVolume < 0 || settings.soundVolume > 100) {
      errors.push('音量必须在 0-100 之间')
    }
  }
  
  // 验证空白检测阈值
  if (settings.blankDetectionThreshold !== undefined) {
    if (typeof settings.blankDetectionThreshold !== 'number') {
      errors.push('空白检测阈值必须是数字')
    } else if (settings.blankDetectionThreshold < 0 || settings.blankDetectionThreshold > 100) {
      errors.push('空白检测阈值必须在 0-100 之间')
    }
  }
  
  // 验证 AI 温度参数
  if (settings.temperature !== undefined) {
    if (typeof settings.temperature !== 'number') {
      errors.push('temperature 必须是数字')
    } else if (settings.temperature < 0 || settings.temperature > 2) {
      errors.push('temperature 必须在 0-2 之间（推荐 0.3-0.7）')
    }
  }
  
  // 验证最大 token 数
  if (settings.maxTokens !== undefined) {
    if (typeof settings.maxTokens !== 'number') {
      errors.push('maxTokens 必须是数字')
    } else if (settings.maxTokens < 100 || settings.maxTokens > 8192) {
      errors.push('maxTokens 必须在 100-8192 之间')
      warnings.push('过大的 maxTokens 可能导致请求失败或费用增加')
    }
  }
  
  // 验证 PaddleOCR 配置
  if (settings.paddleOcrUrl !== undefined) {
    if (!isValidUrl(settings.paddleOcrUrl)) {
      errors.push('PaddleOCR 服务器地址必须是有效的 URL')
    }
  }
  
  if (settings.paddleOcrTimeout !== undefined) {
    if (typeof settings.paddleOcrTimeout !== 'number') {
      errors.push('PaddleOCR 超时时间必须是数字')
    } else if (settings.paddleOcrTimeout < 5 || settings.paddleOcrTimeout > 600) {
      errors.push('PaddleOCR 超时时间必须在 5-600 秒之间')
    }
  }
  
  // 验证批改设置
  if (settings.autoSaveInterval !== undefined) {
    if (typeof settings.autoSaveInterval !== 'number') {
      errors.push('自动保存间隔必须是数字')
    } else if (settings.autoSaveInterval < 10 || settings.autoSaveInterval > 3600) {
      errors.push('自动保存间隔必须在 10-3600 秒之间')
    }
  }
  
  if (settings.batchSize !== undefined) {
    if (typeof settings.batchSize !== 'number') {
      errors.push('批量大小必须是数字')
    } else if (settings.batchSize < 1 || settings.batchSize > 100) {
      errors.push('批量大小必须在 1-100 之间')
    }
  }
  
  if (settings.retryAttempts !== undefined) {
    if (typeof settings.retryAttempts !== 'number') {
      errors.push('重试次数必须是数字')
    } else if (settings.retryAttempts < 0 || settings.retryAttempts > 10) {
      errors.push('重试次数必须在 0-10 之间')
    }
  }
  
  // 验证主题设置
  if (settings.theme !== undefined) {
    const validThemes = ['light', 'dark', 'system']
    if (!validThemes.includes(settings.theme)) {
      errors.push(`主题必须是以下值之一：${validThemes.join(', ')}`)
    }
  }
  
  // 验证字体大小
  if (settings.fontSize !== undefined) {
    const validSizes = ['small', 'medium', 'large']
    if (!validSizes.includes(settings.fontSize)) {
      errors.push(`字体大小必须是以下值之一：${validSizes.join(', ')}`)
    }
  }
  
  // 验证服务商配置
  if (settings.providers && Array.isArray(settings.providers)) {
    settings.providers.forEach((provider, index) => {
      const providerErrors = validateProvider(provider, index)
      errors.push(...providerErrors)
    })
    
    // 检查是否有活跃的服务商
    const activeProviders = settings.providers.filter(p => p.isActive)
    if (activeProviders.length === 0 && settings.providers.length > 0) {
      warnings.push('没有启用的 AI 服务商，请至少启用一个服务商')
    }
    
    // 检查活跃服务商的 API Key
    activeProviders.forEach(provider => {
      if (!provider.apiKey || provider.apiKey.trim().length === 0) {
        errors.push(`服务商 "${provider.name}" 已启用但未配置 API Key`)
      }
    })
  }
  
  // 验证活跃服务商 ID
  if (settings.activeProviderId !== undefined && settings.providers) {
    const providerExists = settings.providers.some(p => p.id === settings.activeProviderId)
    if (!providerExists) {
      errors.push('指定的活跃服务商不存在')
    }
  }
  
  return {
    valid: errors.length === 0,
    errors,
    warnings,
  }
}

/**
 * 验证单个服务商配置
 */
export function validateSingleProvider(provider: AiProvider): ValidationResult {
  const errors = validateProvider(provider, 0)
  const warnings: string[] = []
  
  if (!provider.isActive && provider.apiKey) {
    warnings.push('服务商未启用，配置将不会生效')
  }
  
  return {
    valid: errors.length === 0,
    errors,
    warnings,
  }
}

/**
 * 验证智学网 URL
 */
export function validateZhixueUrl(url: string): { valid: boolean; error?: string } {
  if (!url || url.trim().length === 0) {
    return { valid: false, error: 'URL 不能为空' }
  }
  
  if (!isValidUrl(url)) {
    return { valid: false, error: 'URL 格式不正确' }
  }
  
  if (!url.includes('zhixue.com') && !url.includes('zhixueyun.com')) {
    return { valid: false, error: '本工具仅支持智学网平台 (zhixue.com 或 zhixueyun.com)' }
  }
  
  return { valid: true }
}

/**
 * 验证评分标准
 */
export function validateGradingStandard(standard: {
  name?: string
  totalScore?: number
  scoringRules?: any[]
  referenceAnswer?: string
}): ValidationResult {
  const errors: string[] = []
  const warnings: string[] = []
  
  if (!standard.name || standard.name.trim().length === 0) {
    errors.push('评分标准名称不能为空')
  }
  
  if (standard.totalScore === undefined) {
    errors.push('总分不能为空')
  } else if (typeof standard.totalScore !== 'number') {
    errors.push('总分必须是数字')
  } else if (standard.totalScore <= 0) {
    errors.push('总分必须大于 0')
  } else if (standard.totalScore > 100) {
    warnings.push('总分超过 100 分，请确认是否正确')
  }
  
  if (!standard.referenceAnswer || standard.referenceAnswer.trim().length === 0) {
    warnings.push('参考答案为空，可能影响评分准确性')
  }
  
  if (standard.scoringRules && standard.scoringRules.length === 0) {
    warnings.push('没有配置评分规则，AI 可能无法准确评分')
  }
  
  return {
    valid: errors.length === 0,
    errors,
    warnings,
  }
}

/**
 * 抛出验证错误（如果验证失败）
 */
export function assertValidSettings(settings: Partial<AppSettings>): void {
  const result = validateSettings(settings)
  if (!result.valid) {
    throw new AppError(
      `配置验证失败：${result.errors.join(', ')}`,
      'CONFIG_VALIDATION_FAILED',
      'high',
      { errors: result.errors, warnings: result.warnings }
    )
  }
}
