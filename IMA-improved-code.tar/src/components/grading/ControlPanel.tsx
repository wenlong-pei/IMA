import React from 'react'
import { Play, Pause, Square } from 'lucide-react'

interface ControlPanelProps {
  isRunning: boolean
  isPaused: boolean
  browserConnected: boolean
  onStart: () => void
  onPause: () => void
  onStop: () => void
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  isRunning,
  isPaused,
  browserConnected,
  onStart,
  onPause,
  onStop,
}) => {
  return (
    <div className="card">
      <div className="card-header">
        <Play size={16} />
        <h3>批改控制</h3>
      </div>
      <div className="card-body">
        <div className="control-buttons">
          {!isRunning ? (
            <button
              className="btn btn-primary btn-large"
              onClick={onStart}
              disabled={!browserConnected}
              style={{ width: '100%' }}
            >
              <Play size={20} />
              开始自动批改
            </button>
          ) : (
            <>
              <button
                className={`btn ${isPaused ? 'btn-success' : 'btn-warning'} btn-large`}
                onClick={onPause}
                style={{ flex: 1 }}
              >
                {isPaused ? <Play size={20} /> : <Pause size={20} />}
                {isPaused ? '继续' : '暂停'}
              </button>
              <button
                className="btn btn-danger btn-large"
                onClick={onStop}
                style={{ flex: 1, marginLeft: 10 }}
              >
                <Square size={20} />
                停止
              </button>
            </>
          )}
        </div>

        {isRunning && (
          <div className="running-status">
            <div className="status-indicator running"></div>
            <span>{isPaused ? '已暂停' : '正在批改...'}</span>
          </div>
        )}
      </div>
    </div>
  )
}

export default ControlPanel
