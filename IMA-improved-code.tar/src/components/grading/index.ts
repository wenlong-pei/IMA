// Grading 组件统一导出
export { UrlConfigPanel } from './UrlConfigPanel'
export { StandardSelector } from './StandardSelector'
export { ModeSelector } from './ModeSelector'
export { ControlPanel } from './ControlPanel'

// 默认导出所有组件
import { UrlConfigPanel } from './UrlConfigPanel'
import { StandardSelector } from './StandardSelector'
import { ModeSelector } from './ModeSelector'
import { ControlPanel } from './ControlPanel'

export default {
  UrlConfigPanel,
  StandardSelector,
  ModeSelector,
  ControlPanel,
}
