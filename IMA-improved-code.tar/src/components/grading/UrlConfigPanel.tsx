import React, { useState } from 'react'
import { Link, CheckCircle, AlertCircle } from 'lucide-react'
import toast from 'react-hot-toast'
import { validateZhixueUrl } from '@/utils/configValidator'

interface UrlConfigPanelProps {
  url: string
  setUrl: (url: string) => void
  browserConnected: boolean
  onConnect: () => Promise<void>
  disabled?: boolean
}

export const UrlConfigPanel: React.FC<UrlConfigPanelProps> = ({
  url,
  setUrl,
  browserConnected,
  onConnect,
  disabled = false,
}) => {
  const [validationError, setValidationError] = useState<string | null>(null)

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newUrl = e.target.value
    setUrl(newUrl)
    
    // 实时验证
    if (newUrl.trim()) {
      const result = validateZhixueUrl(newUrl)
      setValidationError(result.valid ? null : (result.error || null))
    } else {
      setValidationError(null)
    }
  }

  const handleConnectClick = async () => {
    if (!url.trim()) {
      toast.error('请输入智学网链接')
      return
    }

    const result = validateZhixueUrl(url)
    if (!result.valid) {
      toast.error(result.error)
      return
    }

    await onConnect()
  }

  return (
    <div className="card">
      <div className="card-header">
        <Link size={16} />
        <h3>智学网链接</h3>
      </div>
      <div className="card-body">
        <div className="url-input-wrapper">
          <input
            type="url"
            value={url}
            onChange={handleUrlChange}
            placeholder="https://www.zhixue.com/..."
            disabled={disabled}
            className={validationError ? 'error' : ''}
          />
          {validationError && (
            <div className="validation-error">
              <AlertCircle size={14} />
              <span>{validationError}</span>
            </div>
          )}
        </div>
        <button
          className={`btn ${browserConnected ? 'btn-success' : 'btn-primary'}`}
          onClick={handleConnectClick}
          disabled={disabled || !url}
          style={{ width: '100%', marginTop: 10 }}
        >
          {browserConnected ? <CheckCircle size={16} /> : <Link size={16} />}
          {browserConnected ? '已连接' : '打开链接'}
        </button>
      </div>
      {browserConnected && (
        <div className="card-footer">
          <span className="badge badge-success">智学网页面已识别</span>
        </div>
      )}
    </div>
  )
}

export default UrlConfigPanel
