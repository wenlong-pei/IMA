import React from 'react'
import { FileText, Plus } from 'lucide-react'
import { useStandardsStore } from '@/store/standardsStore'

interface StandardSelectorProps {
  currentStandardId?: string
  setCurrentStandard: (id: string) => void
  disabled?: boolean
}

export const StandardSelector: React.FC<StandardSelectorProps> = ({
  currentStandardId,
  setCurrentStandard,
  disabled = false,
}) => {
  const { standards } = useStandardsStore()

  return (
    <div className="card">
      <div className="card-header">
        <FileText size={16} />
        <h3>评分标准</h3>
      </div>
      <div className="card-body">
        {standards.length === 0 ? (
          <div className="empty-tip">
            <p>暂无评分标准</p>
            <a href="#/standards">去创建</a>
          </div>
        ) : (
          <div className="standards-list">
            {standards.map((s) => (
              <div
                key={s.id}
                className={`standard-item ${currentStandardId === s.id ? 'active' : ''}`}
                onClick={() => !disabled && setCurrentStandard(s.id)}
                style={{
                  cursor: disabled ? 'not-allowed' : 'pointer',
                  opacity: disabled ? 0.6 : 1,
                }}
              >
                <div className="standard-info">
                  <div className="standard-name">{s.name}</div>
                  <div className="standard-meta">
                    <span className="badge">满分{s.totalScore}分</span>
                    {s.scoringRules && s.scoringRules.length > 0 && (
                      <span className="badge badge-info">
                        {s.scoringRules.length}条规则
                      </span>
                    )}
                  </div>
                </div>
                {currentStandardId === s.id && (
                  <div className="standard-check">✓</div>
                )}
              </div>
            ))}
          </div>
        )}
        {standards.length > 0 && (
          <button
            className="btn btn-secondary"
            onClick={() => (window.location.hash = '#/standards')}
            disabled={disabled}
            style={{ width: '100%', marginTop: 10 }}
          >
            <Plus size={16} />
            管理评分标准
          </button>
        )}
      </div>
    </div>
  )
}

export default StandardSelector
