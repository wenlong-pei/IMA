import React from 'react'
import { Zap, UserCheck, Bot } from 'lucide-react'
import type { GradingMode } from '@/types'

interface ModeSelectorProps {
  gradingMode: GradingMode
  setGradingMode: (mode: GradingMode) => void
  disabled?: boolean
}

const modeConfigs = [
  {
    key: 'normal' as GradingMode,
    icon: <Zap size={18} />,
    name: '普通模式',
    desc: 'AI 评分后 5 秒自动提交，期间可暂停或取消',
  },
  {
    key: 'trial' as GradingMode,
    icon: <UserCheck size={18} />,
    name: '试改模式',
    desc: 'AI 评分后等待教师确认，支持分数纠错和标准优化',
  },
  {
    key: 'unattended' as GradingMode,
    icon: <Bot size={18} />,
    name: '无人值守',
    desc: '全自动批改，1 秒提交，错误自动重试（最多 3 次）',
  },
]

export const ModeSelector: React.FC<ModeSelectorProps> = ({
  gradingMode,
  setGradingMode,
  disabled = false,
}) => {
  return (
    <div className="card">
      <div className="card-header">
        <Zap size={16} />
        <h3>批改模式</h3>
      </div>
      <div className="card-body">
        <div className="mode-selector">
          {modeConfigs.map((mode) => (
            <div
              key={mode.key}
              className={`mode-option ${gradingMode === mode.key ? 'active' : ''}`}
              onClick={() => !disabled && setGradingMode(mode.key)}
              style={{
                cursor: disabled ? 'not-allowed' : 'pointer',
                opacity: disabled ? 0.6 : 1,
              }}
            >
              <div className="mode-icon">{mode.icon}</div>
              <div className="mode-info">
                <div className="mode-name">{mode.name}</div>
                <div className="mode-desc">{mode.desc}</div>
              </div>
              {gradingMode === mode.key && (
                <div className="mode-check">✓</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default ModeSelector
