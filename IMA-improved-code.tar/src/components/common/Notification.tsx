import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { CheckCircle, XCircle, AlertCircle, Info, X } from 'lucide-react'

export type NotificationType = 'success' | 'error' | 'warning' | 'info'

export interface Notification {
  id: string
  type: NotificationType
  title: string
  message: string
  duration?: number
}

interface NotificationItemProps {
  notification: Notification
  onClose: (id: string) => void
}

const NotificationItem: React.FC<NotificationItemProps> = ({ notification, onClose }) => {
  const icons = {
    success: CheckCircle,
    error: XCircle,
    warning: AlertCircle,
    info: Info,
  }

  const colors = {
    success: { bg: '#dcfce7', border: '#22c55e', text: '#166534', icon: '#22c55e' },
    error: { bg: '#fee2e2', border: '#ef4444', text: '#991b1b', icon: '#ef4444' },
    warning: { bg: '#fef3c7', border: '#f59e0b', text: '#92400e', icon: '#f59e0b' },
    info: { bg: '#dbeafe', border: '#3b82f6', text: '#1e40af', icon: '#3b82f6' },
  }

  const Icon = icons[notification.type]
  const color = colors[notification.type]

  return (
    <motion.div
      initial={{ opacity: 0, x: 300, scale: 0.9 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: 300, scale: 0.9 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      style={{
        backgroundColor: color.bg,
        borderLeft: `4px solid ${color.border}`,
        borderRadius: '8px',
        padding: '16px',
        marginBottom: '12px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        display: 'flex',
        alignItems: 'flex-start',
        gap: '12px',
        maxWidth: '400px',
        minWidth: '320px',
      }}
    >
      <Icon size={24} color={color.icon} style={{ flexShrink: 0, marginTop: '2px' }} />
      
      <div style={{ flex: 1 }}>
        <h4 style={{ 
          margin: '0 0 4px 0', 
          fontSize: '15px', 
          fontWeight: '600',
          color: color.text,
        }}>
          {notification.title}
        </h4>
        <p style={{ 
          margin: 0, 
          fontSize: '14px', 
          lineHeight: 1.5,
          color: color.text,
          opacity: 0.9,
        }}>
          {notification.message}
        </p>
      </div>

      <button
        onClick={() => onClose(notification.id)}
        style={{
          background: 'transparent',
          border: 'none',
          cursor: 'pointer',
          padding: '4px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          opacity: 0.6,
          transition: 'opacity 0.2s',
        }}
        onMouseEnter={(e) => e.currentTarget.style.opacity = '1'}
        onMouseLeave={(e) => e.currentTarget.style.opacity = '0.6'}
      >
        <X size={18} color={color.text} />
      </button>
    </motion.div>
  )
}

interface NotificationContainerProps {
  notifications: Notification[]
  onRemove: (id: string) => void
}

export const NotificationContainer: React.FC<NotificationContainerProps> = ({ 
  notifications, 
  onRemove 
}) => {
  const handleRemove = (id: string) => {
    onRemove(id)
  }

  return (
    <div style={{
      position: 'fixed',
      top: '80px',
      right: '20px',
      zIndex: 9999,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
    }}>
      <AnimatePresence>
        {notifications.map(notification => (
          <NotificationItem
            key={notification.id}
            notification={notification}
            onClose={handleRemove}
          />
        ))}
      </AnimatePresence>
    </div>
  )
}

/**
 * 通知管理器 Hook
 */
export function useNotification() {
  const [notifications, setNotifications] = useState<Notification[]>([])

  const addNotification = (
    type: NotificationType,
    title: string,
    message: string,
    duration: number = 5000
  ) => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    const notification: Notification = { id, type, title, message, duration }

    setNotifications(prev => [...prev, notification])

    // 自动关闭
    if (duration > 0) {
      setTimeout(() => {
        setNotifications(prev => prev.filter(n => n.id !== id))
      }, duration)
    }

    return id
  }

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  const success = (title: string, message: string, duration?: number) =>
    addNotification('success', title, message, duration)

  const error = (title: string, message: string, duration?: number) =>
    addNotification('error', title, message, duration)

  const warning = (title: string, message: string, duration?: number) =>
    addNotification('warning', title, message, duration)

  const info = (title: string, message: string, duration?: number) =>
    addNotification('info', title, message, duration)

  const clearAll = () => setNotifications([])

  return {
    notifications,
    addNotification,
    removeNotification,
    success,
    error,
    warning,
    info,
    clearAll,
    NotificationContainer: () => (
      <NotificationContainer 
        notifications={notifications} 
        onRemove={removeNotification} 
      />
    ),
  }
}

export default useNotification
