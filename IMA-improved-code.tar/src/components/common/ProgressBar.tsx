import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Loader2, Pause, Play, Square } from 'lucide-react'

export interface ProgressStep {
  id: string
  label: string
  status: 'pending' | 'processing' | 'completed' | 'error'
  error?: string
}

interface ProgressBarProps {
  /** 当前进度百分比 (0-100) */
  progress: number
  /** 是否显示百分比文本 */
  showPercentage?: boolean
  /** 是否显示动画 */
  animated?: boolean
  /** 进度条颜色 */
  color?: string
  /** 高度（像素） */
  height?: number
  /** 条纹动画 */
  striped?: boolean
  /** 自定义标签 */
  label?: string
  /** 子任务列表 */
  steps?: ProgressStep[]
  /** 预计剩余时间（秒） */
  estimatedTimeRemaining?: number
  /** 当前处理项 */
  currentItem?: string
  /** 取消按钮回调 */
  onCancel?: () => void
  /** 暂停/继续回调 */
  onPauseToggle?: (paused: boolean) => void
  /** 是否可暂停 */
  pauseable?: boolean
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  showPercentage = true,
  animated = true,
  color = '#3b82f6',
  height = 8,
  striped = false,
  label,
  steps,
  estimatedTimeRemaining,
  currentItem,
  onCancel,
  onPauseToggle,
  pauseable = false,
}) => {
  const [isPaused, setIsPaused] = useState(false)
  const clampedProgress = Math.min(Math.max(progress, 0), 100)

  // 格式化剩余时间
  const formatTime = (seconds: number): string => {
    if (seconds < 60) return `${Math.round(seconds)}秒`
    const mins = Math.floor(seconds / 60)
    const secs = Math.round(seconds % 60)
    return `${mins}分${secs}秒`
  }

  const handlePauseToggle = () => {
    const newState = !isPaused
    setIsPaused(newState)
    onPauseToggle?.(newState)
  }

  return (
    <div style={{ width: '100%' }}>
      {/* 主进度条 */}
      <div style={{ marginBottom: steps ? '16px' : '0' }}>
        {/* 标签和状态行 */}
        {(label || showPercentage || pauseable || onCancel) && (
          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            marginBottom: '8px',
          }}>
            {label && (
              <span style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#475569',
              }}>
                {label}
                {currentItem && (
                  <span style={{ marginLeft: '8px', opacity: 0.7, fontSize: '13px' }}>
                    - {currentItem}
                  </span>
                )}
              </span>
            )}
            
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              {estimatedTimeRemaining !== undefined && (
                <span style={{ fontSize: '13px', color: '#64748b' }}>
                  预计剩余：{formatTime(estimatedTimeRemaining)}
                </span>
              )}
              
              {showPercentage && (
                <span style={{ 
                  fontSize: '14px', 
                  fontWeight: '600',
                  color: '#475569',
                  minWidth: '50px',
                  textAlign: 'right',
                }}>
                  {clampedProgress.toFixed(1)}%
                </span>
              )}
              
              {pauseable && (
                <button
                  onClick={handlePauseToggle}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    opacity: 0.7,
                    transition: 'opacity 0.2s',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.opacity = '1'}
                  onMouseLeave={(e) => e.currentTarget.style.opacity = '0.7'}
                  title={isPaused ? '继续' : '暂停'}
                >
                  {isPaused ? <Play size={18} color="#475569" /> : <Pause size={18} color="#475569" />}
                </button>
              )}
              
              {onCancel && (
                <button
                  onClick={onCancel}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    opacity: 0.7,
                    transition: 'opacity 0.2s',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.opacity = '1'}
                  onMouseLeave={(e) => e.currentTarget.style.opacity = '0.7'}
                  title="取消"
                >
                  <Square size={18} color="#ef4444" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* 进度条容器 */}
        <div style={{
          width: '100%',
          height: `${height}px`,
          backgroundColor: '#e2e8f0',
          borderRadius: `${height / 2}px`,
          overflow: 'hidden',
          position: 'relative',
        }}>
          {/* 进度条填充 */}
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${clampedProgress}%` }}
            transition={{ duration: animated ? 0.3 : 0 }}
            style={{
              height: '100%',
              backgroundColor: color,
              borderRadius: `${height / 2}px`,
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            {/* 条纹动画 */}
            {striped && (
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundImage: `linear-gradient(
                  45deg,
                  rgba(255, 255, 255, 0.15) 25%,
                  transparent 25%,
                  transparent 50%,
                  rgba(255, 255, 255, 0.15) 50%,
                  rgba(255, 255, 255, 0.15) 75%,
                  transparent 75%,
                  transparent
                )`,
                backgroundSize: `${height * 2}px ${height * 2}px`,
                animation: isPaused ? 'none' : 'progress-bar-stripes 1s linear infinite',
              }} />
            )}
          </motion.div>
        </div>
      </div>

      {/* 子任务步骤列表 */}
      {steps && steps.length > 0 && (
        <div style={{ 
          marginTop: '16px',
          padding: '12px',
          backgroundColor: '#f8fafc',
          borderRadius: '8px',
        }}>
          {steps.map((step, index) => (
            <ProgressStepItem key={step.id} step={step} isLast={index === steps.length - 1} />
          ))}
        </div>
      )}

      {/* 条纹动画 CSS */}
      <style>{`
        @keyframes progress-bar-stripes {
          0% { background-position: ${height * 2}px 0; }
          100% { background-position: 0 0; }
        }
      `}</style>
    </div>
  )
}

interface ProgressStepItemProps {
  step: ProgressStep
  isLast: boolean
}

const ProgressStepItem: React.FC<ProgressStepItemProps> = ({ step, isLast }) => {
  const statusConfig = {
    pending: { icon: null, color: '#94a3b8', bgColor: '#f1f5f9' },
    processing: { icon: <Loader2 size={16} className="animate-spin" />, color: '#3b82f6', bgColor: '#dbeafe' },
    completed: { icon: '✓', color: '#22c55e', bgColor: '#dcfce7' },
    error: { icon: '✗', color: '#ef4444', bgColor: '#fee2e2' },
  }

  const config = statusConfig[step.status]

  return (
    <>
      <div style={{ 
        display: 'flex', 
        alignItems: 'center',
        gap: '12px',
        padding: '8px 0',
      }}>
        {/* 状态图标 */}
        <div style={{
          width: '28px',
          height: '28px',
          borderRadius: '50%',
          backgroundColor: config.bgColor,
          color: config.color,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '14px',
          fontWeight: 'bold',
          flexShrink: 0,
        }}>
          {config.icon || <div style={{ width: 16, height: 16 }} />}
        </div>

        {/* 标签 */}
        <span style={{
          flex: 1,
          fontSize: '14px',
          color: step.status === 'error' ? '#ef4444' : '#475569',
          textDecoration: step.status === 'error' ? 'line-through' : 'none',
        }}>
          {step.label}
          {step.error && (
            <span style={{ display: 'block', fontSize: '12px', color: '#ef4444', marginTop: '4px' }}>
              {step.error}
            </span>
          )}
        </span>

        {/* 状态文本 */}
        <span style={{
          fontSize: '12px',
          color: config.color,
          fontWeight: '500',
          textTransform: 'capitalize',
        }}>
          {step.status === 'processing' ? '进行中...' : 
           step.status === 'completed' ? '已完成' : 
           step.status === 'error' ? '失败' : '等待中'}
        </span>
      </div>

      {/* 连接线 */}
      {!isLast && (
        <div style={{
          width: '2px',
          height: '24px',
          backgroundColor: '#e2e8f0',
          marginLeft: '13px',
        }} />
      )}
    </>
  )
}

export default ProgressBar
