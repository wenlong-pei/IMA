import React, { Component, ErrorInfo, ReactNode } from 'react'
import { AppError, ErrorUtils } from '../utils/AppError'
import { AlertTriangle, RefreshCw, Home, Bug } from 'lucide-react'

interface Props {
  children: ReactNode
  fallback?: ReactNode
  onError?: (error: Error, errorInfo: ErrorInfo) => void
}

interface State {
  hasError: boolean
  error: Error | null
  errorInfo: ErrorInfo | null
}

/**
 * 错误边界组件
 * 捕获子组件树中的 JavaScript 错误，防止整个应用崩溃
 */
export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    }
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // 保存错误信息
    this.setState({ errorInfo })

    // 调用外部错误处理回调
    if (this.props.onError) {
      this.props.onError(error, errorInfo)
    }

    // 记录错误日志（生产环境可发送到 Sentry 等监控服务）
    console.error('ErrorBoundary caught an error:', error, errorInfo)
    
    // 将错误转换为 AppError 以便统一处理
    const appError = AppError.fromError(error, 'REACT_COMPONENT_ERROR')
    console.error('AppError details:', appError.toJSON())
  }

  handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
    })
  }

  handleReload = () => {
    window.location.reload()
  }

  handleGoHome = () => {
    window.location.href = '/'
  }

  render() {
    if (this.state.hasError) {
      // 如果提供了自定义 fallback，使用它
      if (this.props.fallback) {
        return this.props.fallback
      }

      // 默认的错误 UI
      const appError = this.state.error ? AppError.fromError(this.state.error) : null
      const userMessage = appError 
        ? ErrorUtils.getUserFriendlyMessage(appError.code, appError.details)
        : '组件渲染时发生错误'
      
      const isRecoverable = appError ? ErrorUtils.isRecoverable(appError) : true

      return (
        <div style={styles.container}>
          <div style={styles.card}>
            <div style={styles.icon}>
              <AlertTriangle size={48} color="#f59e0b" />
            </div>
            
            <h1 style={styles.title}>哎呀，出错了！</h1>
            
            <p style={styles.message}>{userMessage}</p>
            
            {this.state.error && (
              <details style={styles.details}>
                <summary style={styles.summary}>技术详情（点击展开）</summary>
                <div style={styles.errorCode}>
                  <strong>错误代码：</strong> {appError?.code || 'UNKNOWN'}
                </div>
                <div style={styles.errorCode}>
                  <strong>严重程度：</strong> {appError?.severity || 'medium'}
                </div>
                <pre style={styles.stackTrace}>
                  {this.state.error.toString()}
                  {this.state.errorInfo?.componentStack}
                </pre>
              </details>
            )}

            <div style={styles.actions}>
              {isRecoverable && (
                <button style={styles.retryButton} onClick={this.handleReset}>
                  <RefreshCw size={18} />
                  重试
                </button>
              )}
              
              <button style={styles.reloadButton} onClick={this.handleReload}>
                <RefreshCw size={18} />
                刷新页面
              </button>
              
              <button style={styles.homeButton} onClick={this.handleGoHome}>
                <Home size={18} />
                返回首页
              </button>
              
              <button 
                style={styles.reportButton} 
                onClick={() => window.open('https://github.com/pilaoban/grading-tool/issues', '_blank')}
              >
                <Bug size={18} />
                报告问题
              </button>
            </div>

            <p style={styles.hint}>
              💡 提示：如果问题持续存在，请尝试刷新页面或联系技术支持
            </p>
          </div>
        </div>
      )
    }

    return this.props.children
  }
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f8fafc',
    padding: '20px',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: '12px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    padding: '40px',
    maxWidth: '600px',
    width: '100%',
    textAlign: 'center',
  },
  icon: {
    marginBottom: '20px',
  },
  title: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#1e293b',
    marginBottom: '16px',
  },
  message: {
    fontSize: '16px',
    color: '#64748b',
    marginBottom: '24px',
    lineHeight: 1.6,
  },
  details: {
    textAlign: 'left',
    marginBottom: '24px',
    padding: '16px',
    backgroundColor: '#f1f5f9',
    borderRadius: '8px',
    fontSize: '14px',
  },
  summary: {
    cursor: 'pointer',
    color: '#64748b',
    fontWeight: '500',
    marginBottom: '12px',
  },
  errorCode: {
    marginBottom: '8px',
    color: '#475569',
  },
  stackTrace: {
    backgroundColor: '#1e293b',
    color: '#f8fafc',
    padding: '12px',
    borderRadius: '6px',
    overflow: 'auto',
    fontSize: '12px',
    textAlign: 'left',
    maxHeight: '200px',
  },
  actions: {
    display: 'flex',
    gap: '12px',
    justifyContent: 'center',
    flexWrap: 'wrap',
    marginBottom: '20px',
  },
  retryButton: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
    padding: '12px 24px',
    backgroundColor: '#3b82f6',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    transition: 'background-color 0.2s',
  },
  reloadButton: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
    padding: '12px 24px',
    backgroundColor: '#10b981',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    transition: 'background-color 0.2s',
  },
  homeButton: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
    padding: '12px 24px',
    backgroundColor: '#64748b',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    transition: 'background-color 0.2s',
  },
  reportButton: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
    padding: '12px 24px',
    backgroundColor: '#f59e0b',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    transition: 'background-color 0.2s',
  },
  hint: {
    fontSize: '14px',
    color: '#94a3b8',
    fontStyle: 'italic',
  },
}

export default ErrorBoundary
